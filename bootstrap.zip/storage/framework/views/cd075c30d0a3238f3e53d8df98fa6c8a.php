<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('home')); ?>">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <!-- End Dashboard Nav -->


        <!-- Start Consolve Nav -->
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('consolve')); ?>">
                <i class="fa fa-dice"></i>
                <span>Consolve</span>
            </a>
        </li>
        <!-- End Consolve Nav -->


        <!-- Start App Ad -->
        <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('app_add')); ?>">
                <i class="fab fa-app-store"></i>
                <span>App</span>
            </a>
        </li>
        <!-- End App Ad -->

        <!-- Start Category -->


















        <!-- End Category   -->

        <li class="nav-heading">Pages</li>

        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('user_profile')); ?>">
                <i class="bi bi-person"></i>
                <span>Profile</span>
            </a>
        </li>
        <!-- End Profile Page Nav -->

        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('contact')); ?>">
                <i class="bi bi-envelope"></i>
                <span>Contact</span>
            </a>
        </li>
        <!-- End Contact Page Nav -->
    </ul>

</aside>
<!-- End Sidebar-->
<?php /**PATH C:\xampp\htdocs\App_Manager_adminpenal\resources\views/master/sidebar.blade.php ENDPATH**/ ?>