<?php $__env->startSection('content_name'); ?>
    <h1>Consolve</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?><?php echo e(__('Consolve')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('item'); ?>
    <li class="breadcrumb-item active">Consolve</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="row pl-3 pr-3">
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php elseif(session('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <div class="pb-2 pr-3">
                <button type="button" class="btn btn-primary btn-lg float-end" data-toggle="modal" data-target="#createModal">+</button>
            </div>
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body mt-3">
                        <!-- Table with stripped rows -->
                        <table class="table datatable mt-3">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Person name</th>
                                <th scope="col">Gmail</th>
                                <th scope="col">Mobile</th>
                                <th scope="col">Account link</th>
                                <th scope="col">Account country</th>
                                <th scope="col">Order id</th>
                                <th scope="col">Account id</th>
                                <th scope="col">Created at</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $consolve_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($k+1); ?></th>

                                    <td><?php echo e($data->name); ?></td>
                                    <td><?php echo e($data->person_name); ?></td>
                                    <td><?php echo e($data->gmail); ?></td>
                                    <td><?php echo e($data->mobile); ?></td>
                                    <td><?php echo e($data->account_link); ?></td>
                                    <td><?php echo e($data->account_country); ?></td>
                                    <td><?php echo e($data->order_id); ?></td>
                                    <td><?php echo e($data->account_id); ?></td>
                                    <td><?php echo e(date('d-m-Y', strtotime($data->created_at))); ?></td>
                                    <td><?php echo e($data->status); ?></td>
                                    <td>


                                        <button type="button" id="action-<?php echo e($data->id); ?>"><i class="fas fa-arrow-circle-down"></i></button>
                                    </td>
                                </tr>
                                <tr class="">
                                    <td>
                                        <a href="<?php echo e(url('edit-blog/'.$data->id)); ?>" class="btn btn-success btn-sm rounded-0" type="button" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"></i></a>
                                        <a href="<?php echo e(url('delete-blog/'.$data->id)); ?>" class="btn btn-danger btn-sm rounded-0" type="button" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
        <div class="modal fade" id="createModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel">Add Consolve </h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <form action="<?php echo e(route('create.consolve')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                        <div class="modal-body">
                               <div class="form-group">
                                   <label for="email1">Name <span style="color: red">*</span></label>
                                   <input type="text" name="name" class="form-control" id="name" aria-describedby="name" placeholder="Name">
                               </div>
                               <div class="form-group">
                                   <label for="email1">Person name <span style="color: red">*</span></label>
                                   <input type="text" name="person_name" class="form-control" id="person_name" aria-describedby="person_name" placeholder="Person name">
                               </div>
                               <div class="form-group">
                                   <label for="gmail">Gmail <span style="color: red">*</span></label>
                                   <input type="email" name="gmail" class="form-control" id="gmail" aria-describedby="gmail" placeholder="Gmail">
                               </div>
                               <div class="form-group">
                                   <label for="email1">Mobile <span style="color: red">*</span></label>
                                   <input type="text" name="mobile" class="form-control" id="mobile" aria-describedby="mobile" placeholder="Mobile">
                               </div>
                               <div class="form-group">
                                   <label for="email1">Account link <span style="color: red">*</span></label>
                                   <input type="text" name="account_link" class="form-control" id="account_link" aria-describedby="account_link" placeholder="Account link">
                               </div>
                               <div class="form-group">
                                   <label for="email1">Account country <span style="color: red">*</span></label>
                                   <input type="text" name="account_country" class="form-control" id="account_country" aria-describedby="account_country" placeholder="Account country">
                               </div>
                               <div class="form-group">
                                   <label for="email1">Order id <span style="color: red">*</span></label>
                                   <input type="text" name="order_id" class="form-control" id="order_id" aria-describedby="order_id" placeholder="Order id">
                               </div>
                               <div class="form-group">
                                   <label for="email1">Account id <span style="color: red">*</span></label>
                                   <input type="text" name="account_id" class="form-control" id="account_id" aria-describedby="account_id" placeholder="Account id">
                               </div>
                               <div class="form-group">
                                   <label for="email1">Status <span style="color: red">*</span></label>

                                   <select type="text" name="status" class="form-control" id="status" aria-describedby="status" placeholder="Status">
                                       <option value="">-- Select Stutas --</option>
                                       <option value="Live">Live</option>
                                       <option value="Remove">Remove</option>
                                       <option value="Pending">Pending</option>
                                   </select>
                               </div>
                          </div>

                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Save</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\App_Manager_adminpenal\resources\views/admin/index.blade.php ENDPATH**/ ?>
