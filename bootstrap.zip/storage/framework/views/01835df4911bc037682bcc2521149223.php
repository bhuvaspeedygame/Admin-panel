<?php $__env->startSection('content_name'); ?>
    <h1>Update Consolve</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?><?php echo e(__('Update Consolve')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('item'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('consolve')); ?>">Consolve</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Update Logo</h5>

                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php elseif(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('update_consolve', ['id' => $consolve_data->id])); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="email1">Name <span style="color: red">*</span></label>
                                    <input type="text" name="name" class="form-control" id="name" aria-describedby="name" placeholder="Name" value="<?php echo e($consolve_data->name); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="email1">Person name <span style="color: red">*</span></label>
                                    <input type="text" name="person_name" class="form-control" id="person_name" aria-describedby="person_name" placeholder="Person name" value="<?php echo e($consolve_data->person_name); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="gmail">Gmail <span style="color: red">*</span></label>
                                    <input type="email" name="gmail" class="form-control" id="gmail" aria-describedby="gmail" placeholder="Gmail" value="<?php echo e($consolve_data->gmail); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="email1">Mobile <span style="color: red">*</span></label>
                                    <input type="text" name="mobile" class="form-control" id="mobile" aria-describedby="mobile" placeholder="Mobile" value="<?php echo e($consolve_data->mobile); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="email1">Account link <span style="color: red">*</span></label>
                                    <input type="text" name="account_link" class="form-control" id="account_link" aria-describedby="account_link" placeholder="Account link" value="<?php echo e($consolve_data->account_link); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="email1">Account country <span style="color: red">*</span></label>
                                    <input type="text" name="account_country" class="form-control" id="account_country" aria-describedby="account_country" placeholder="Account country" value="<?php echo e($consolve_data->account_country); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="email1">Order id <span style="color: red">*</span></label>
                                    <input type="text" name="order_id" class="form-control" id="order_id" aria-describedby="order_id" placeholder="Order id" value="<?php echo e($consolve_data->order_id); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="email1">Account id <span style="color: red">*</span></label>
                                    <input type="text" name="account_id" class="form-control" id="account_id" aria-describedby="account_id" placeholder="Account id" value="<?php echo e($consolve_data->account_id); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="email1">Status <span style="color: red">*</span></label>
                                    <select type="text" name="status" class="form-control" id="status" aria-describedby="status" placeholder="Status">
                                        <option value="">-- Select Stutas --</option>
                                        <option value="Live" <?php echo e(($consolve_data->status == "Live")? "selected" :""); ?>>Live</option>
                                        <option value="Remove" <?php echo e(($consolve_data->status == "Remove")? "selected" :""); ?>>Remove</option>
                                        <option value="Pending" <?php echo e(($consolve_data->status == "Pending")? "selected" :""); ?>>Pending</option>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Save</button>
                                <a href="<?php echo e(route('consolve')); ?>" type="button" class="btn btn-secondary" data-dismiss="modal">Back</a>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\App_Manager_adminpenal\resources\views/admin/consolve/update.blade.php ENDPATH**/ ?>